public class InvalidGPAException extends Exception {
    public InvalidGPAException(String message) {
        super(message);
    }
}
