import java.util.List;
public class AutoSaveThread extends Thread{
    private StudentManager manager;
    private volatile boolean running= true;

    public AutoSaveThread(StudentManager manager){
        this.manager= manager;
        setDaemon(true);
    }
 @Override
    public void run(){
        System.out.println("=>> [[AutoSave System]]: Started..");

        while(running){
            try{
                Thread.sleep(30000);
                if(running){
                    List<Student> allStudents= manager.getAllStudents();
                    FileHandler.saveToCSV("autosave.csv", allStudents);
                    System.out.println("=>> [[AutoSave]]: Data saved successfully..");
                }
            }catch (Exception e){
                System.out.println("Error in AutoSave: "+ e.getMessage());
            }
        }
    }
    public void stopService(){
        running= false;
    }
}
