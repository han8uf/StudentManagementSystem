import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.List;

public class ReportThread extends Thread {
    private StudentManager manager;

    public ReportThread(StudentManager manager) {
        this.manager = manager;
    }

    @Override 
    public void run(){
        System.out.println("=>>[[Report System]]: Generating Report in background..");
        try{
           Thread.sleep(2000);
           List<Student> list= manager.getAllStudents();
           int count= list.size();
           double totalGPA= 0;
           for(Student s: list){
             totalGPA += s.getGpa();
            }
           double avg = count > 0 ? totalGPA / count : 0.0;

           PrintWriter writer= new PrintWriter(new FileWriter("final_report.txt"));
           writer.println("==Student Management System Report==");
           writer.println("Total student: "+ count);
           writer.println("Average GPA: "+ String.format("%.2f", avg));
           writer.println("===============================================");
           for(Student s: list){
             writer.println("- "+ s.getFirstName()+ " (GPA: "+ s.getGpa()+ ") ");
            }
           writer.close();
           System.out.println("=>> [[Report]]: Report is ready!..");

        }catch(Exception e){
         System.out.println("Error in Report: "+ e.getMessage());
        }
    }
}
