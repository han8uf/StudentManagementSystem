import java.util.ArrayList;
import java.util.List;

public class StudentManager {

    private List<Student> students = new ArrayList<>();

    public void addStudent(Student s) {
        students.add(s);
    }

    public Student findById(String id) {
        for (Student s : students) {
            if (s.getId().equals(id))
                return s;
        }
        return null;
    }

    public boolean removeStudent(String id) {
        Student s = findById(id);
        if (s != null) {
            students.remove(s);
            return true;
        }
        return false;
    }

    public List<Student> getAllStudents() {
        return students;
    }
}
